package com.examenA;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExamenAJuanGabrielSanchezApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExamenAJuanGabrielSanchezApplication.class, args);
	}

}
