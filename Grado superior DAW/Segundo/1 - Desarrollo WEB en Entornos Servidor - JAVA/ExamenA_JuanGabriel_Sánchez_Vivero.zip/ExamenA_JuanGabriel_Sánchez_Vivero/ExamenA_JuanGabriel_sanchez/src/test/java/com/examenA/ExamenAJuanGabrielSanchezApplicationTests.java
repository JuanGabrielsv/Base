package com.examenA;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExamenAJuanGabrielSanchezApplicationTests {

	@Test
	void contextLoads() {
	}

}
