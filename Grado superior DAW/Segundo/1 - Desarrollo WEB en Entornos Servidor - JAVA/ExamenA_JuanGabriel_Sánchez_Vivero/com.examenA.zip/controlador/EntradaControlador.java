package com.examenA.controlador;

public class EntradaControlador {

}
