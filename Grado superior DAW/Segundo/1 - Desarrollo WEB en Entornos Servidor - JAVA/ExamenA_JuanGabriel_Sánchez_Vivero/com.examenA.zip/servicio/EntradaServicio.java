package com.examenA.servicio;

public class EntradaServicio {

}
