package com.examenA.repositorio;

public class EntradaRepositorio {

}
