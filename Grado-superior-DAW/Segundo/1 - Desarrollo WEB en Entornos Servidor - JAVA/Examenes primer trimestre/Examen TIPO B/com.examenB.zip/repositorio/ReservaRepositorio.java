package com.examenB.repositorio;

public class ReservaRepositorio {

}
